
public class Ornek5 {

	public static void main(String[] args) {
		// OPERAT�R KULLANIMLARI
		
		int sayi1 = 10;
		int sayi2 = 90;
		int toplam = sayi1+sayi2;
		
		int a = 10;
		int b = 7;
		int cikar = a-b;
		
		int c = 10;
		int d = 5;
		int carp = c*d;
		
		int x = 100;
		int z = 5;
		int bol = x/z;
		
		int mod = 10%2;
		
				
		//B�RLE�T�RME OPERAT�R�
		// + �ncesi ve sonras� string ise, string elde edilir.
		// + �ncesi ya da sonras� string ve di�eri de�il ise yine string elde edilir.	
		// Fakat + �ncesi ve sonras� numerik ise toplama i�lemi yapar.
				
				
		//�RNEK1		
		String ad = "�ER�F";
		String soyad = "G�NG�R";
		String adSoyad = ad+" "+soyad;
		System.out.println(adSoyad);
		
		//�RNEK2
		/*String ile string olmayan bir t�r� birle�tirilir ise, yine string elde edilir.*/
		
		String sinif = "B�L���M OKUKLU NO:";
		int sinifNo = 9;
		String sinifAdi = sinif+sinifNo;
		System.out.println(sinifAdi);
		
		//�RNEK3
		int s1 =10;
		int s2 = 9;
		int sonuc = s1+s2;
		System.out.println(sonuc);
		
		
				
	}

}
