
public class Ornek1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				//DE���KEN OLU�TURMA VE DE�ER ATAMA
				short s = 5;
				int i = 10;
				String yazi = "Merhaba Java";
				float f = 10.5f;
				boolean b = true;
				char ch = 'A';
				byte by = 5;
				double d = 9.3d;
				// Ekrana yaz� yazd�rma
				System.out.print(s+" ");
				System.out.print(i+" ");
				System.out.print(yazi+" ");
				System.out.print(f+" ");
				System.out.print(b+" ");
				System.out.print(ch+" ");
				System.out.print(by+" ");
				System.out.print(d+" ");
				
				System.out.println("MERHABA");
				System.out.println("D�NYA");
				
				
				System.out.print("�SMEK\n");
				System.out.print("FAT�H\n");
				System.out.print("B�L���M\n");
				System.out.print("OKULU\n");
				
				
		

	}

}
