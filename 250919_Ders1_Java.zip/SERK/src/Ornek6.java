import java.util.Scanner;

public class Ornek6 {

	public static void main(String[] args) {
		// TOPLAMA �IKARMA B�LME �ARPMA MOD ALDIRMA
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("L�tfen �lk Say�y� Giriniz");
		int ilk = sc.nextInt();
		System.out.println("L�tfen �kinci Say�y� Giriniz");
		int iki = sc.nextInt();
		
		int toplamsonuc = ilk+iki;
		System.out.println("Toplam Sonu�: "+toplamsonuc);
		int cikarsonuc = ilk-iki;
		System.out.println("��karma Sonu�: "+cikarsonuc);
		int carpimsonuc = ilk*iki;
		System.out.println("�arp�m Sonu�: "+carpimsonuc);
		int bolmesonuc = ilk/iki;
		System.out.println("B�lme Sonu�: "+bolmesonuc);
		

	}

}
