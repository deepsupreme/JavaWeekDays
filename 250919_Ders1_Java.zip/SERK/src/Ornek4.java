import java.util.Scanner;

public class Ornek4 {
	static Scanner sc;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	int sayi1,sayi2;
	
	System.out.println("Say�1 giriniz");
	sayi1=sc.nextInt();
	System.out.println("Say�2 giriniz");
	sayi2=sc.nextInt();
	
	int sonuc = sayi1+sayi2;
	System.out.println("Sonu�: "+sonuc);
	
	/*
	 nextFloat
	 nextInt()
	 next()
	 nextLine()
	 nextBoolean()
	 nextShort()
	 nextLong
	 nextDouble
	 
	 
	 */
	
		
		

	}

}
