import java.util.Scanner;

public class Ornek2 {

	public static void main(String[] args) {
		// KULLANICIDAN VER� ALMA
		/* 
		 SCANNER SINIFI SAYES�NDE, KULLANICIDAN VER� G�R��� ALAB�L�RLER
		 */
		Scanner sc = new Scanner(System.in);
		
		System.out.println("L�tfen Ad�n�z� Giriniz");
		String ad = sc.next();
		System.out.println("L�tfen Soyad�n�z� Giriniz");
		String soyad = sc.next();
		
		System.out.println(ad+" "+soyad);
		
		String adSoyad = ad+" "+soyad;
		System.out.println(adSoyad);
		
		
	}

}
