import java.util.Scanner;

public class Ornek3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("L�tfen �lk Say�y� Giriniz");
		int ilk = sc.nextInt();
		System.out.println("L�tfen �kinci Say�y� Giriniz");
		int iki = sc.nextInt();
		
		System.out.println("Sonu�:"+(ilk+iki));

	}

}
