import java.util.Scanner;

public class Ornek2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String[] dizi = new String[3];
		
		
		System.out.println("L�tfen 1.Say�y� Giriniz");
		dizi[0] = sc.next();
		System.out.println("L�tfen 2.Say�y� Giriniz");
		dizi[1] = sc.next();
		System.out.println("L�tfen 3.Say�y� Giriniz");
		dizi[2] = sc.next();
		
		System.out.println(dizi[0]);
		System.out.println(dizi[1]);
		System.out.println(dizi[2]);
		
	}
	
}
	
	