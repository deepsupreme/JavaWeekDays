
public class Ornek4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int[] sayilar = new int[3];
		
		sayilar[2] = 100;
		
		System.out.println(sayilar[0]);
		System.out.println(sayilar[1]);
		System.out.println(sayilar[2]);
		
		System.out.println("----------------");
		
		String[] yazilar = new String[3];
		yazilar[1] = "Merhaba";
		System.out.println(yazilar[0]);
		System.out.println(yazilar[1]);
		System.out.println(yazilar[2]);
		

	}

}
