
public class Ornek3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Object[] obj = new Object[3];
		obj[0] = 5;
		obj[1] = "Merhaba";
		obj[0] = true;
		
   // String veri tipinde de�er atanmad�ysa integer ise 0 olarak de�er atar string ise null atar
	}

}
