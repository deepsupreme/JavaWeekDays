
public class Ornek1 {

	public static void main(String[]args) {
		
		int sayi = 1;
				
				int[] sayilar = new int[5];
				sayilar[0] = 1;
				sayilar[1] = 4;
				sayilar[2] = 8;
				sayilar[3] = 7;
				sayilar[4] = 41;
				
				
				String[] yazilar = new String[4];
				yazilar[0] = "�SMEK";
				yazilar[1] = "FAT�H";
				yazilar[2] = "B�L���M";
				yazilar[3] = "OKULU";
				
				System.out.println(yazilar[2]);
				
				
				
				
	}
}
