
public class Ornek2 {

	public static void main(String[] args) {
		// S�f�rdan ba�lay�p 5'e kadar olan say�lar� ekrana yazd�rma.

		for (int i = 0; i < 5; i++) {

			// i++ birer birer rt�t�r�
			// i+=2 iki�er iki�er art�r�r

			System.out.println(i);
		}

		System.out.println("******");

		// 100'den ba�lay�p 502yekadar olan say�lar� 5'er 5'er yazd�rma.
		for (int i = 100; i >= 50; i -= 5) {
			System.out.println(i);
		}
		// sonsuz d�ng�
		int s = 0;
		for (;;) {
			s++;
			System.out.println("Merhaba");
			if (s == 20) {
				break;

			}
		}

		System.out.println("******");

		// belirtti�imiz say� kadar artt�rma

		int artisMiktari = 5;
		for (int i = 0; i <= 500; i += artisMiktari) {
			if (i == 200) {
				artisMiktari = 4;
			}
			System.out.println(i);

		}

		System.out.println("******");
		
		//Belirtti�imi say� kadar �arpma
		
		for(int i=1; i<=500; i*=5) { System.out.println(i);}
		

	}

}
