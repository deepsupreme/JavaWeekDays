import java.util.Scanner;
public class Ornek4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		String[] dizi = new String[5]; 
		for (int i =0; i <5; i++) {
		
		System.out.println((i+1)+".de�eri giriniz");
		dizi[i] = sc.next();
		}
		
		for (int i =0; i <5; i++) {
			System.out.println(dizi[i]);
			
		}
		
	}

}
