
public class Ornek8 {

	public static void main(String[] args) {
		
		String bosluk=" ey Sevgili ";
		System.out.println(bosluk.trim());
		
		
		

	}

}
