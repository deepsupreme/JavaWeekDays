
public class Ornek5 {

	public static void main(String[] args) {
		
		String sehir ="�stanbul";
		String baskent = "ankara";
		
				if("istanbul".equals(sehir)) {
					System.out.println("�ehir �stanbuldur.");
				}else {
					System.out.println("�ehir �stabul de�ildir.");
				}
				
				if("ANKARA".equalsIgnoreCase(baskent)) {
					System.out.println("Ba�kent ankaraya e�ittir");
				}else {
					System.out.println("ba�kent ankatya e�it de�ildir");
				}
		
		
		
		
		
		
	}
}
