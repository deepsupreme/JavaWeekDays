
public class Ornek9 {

	public static void main(String[] args) {
		String yerles = "Ey Sevgili";
		System.out.println(yerles.replace("Sevgili", "Sevdice�im"));
		

	}

}
