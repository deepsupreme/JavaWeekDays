
public class Ornek7 {

	public static void main(String[] args) {
		
		String kelime ="muvaffakiyetsizle�tiricile�tiriveremeyebileceklerimizdenmi�sinizcesine";
		System.out.println(kelime.length());
		
        String okul = "�smek Fatih Bili�im Okulu";
        System.out.println(okul.length());
        
	}

}
