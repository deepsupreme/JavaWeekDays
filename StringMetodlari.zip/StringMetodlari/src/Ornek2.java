
public class Ornek2 {

	public static void main(String[] args) {
		String okul = "Fatih Bili�im Okulu";
		
		System.out.println(okul.charAt(3));
		System.out.println(okul.contains("a"));
		System.out.println(okul.toUpperCase());
		System.out.println(okul.toLowerCase());
				

	}

}
