
public class Ornek3 {

	public static void main(String[] args) {
		/* belirleen ba�lang�� ve biti� indisleri aras�ndaki de�erlerin okunmas�n� string metodudur.

		 */

		String sehir = "YUNAN�STANBULGAR��TAN";
		System.out.println(sehir.substring(5,13));
		
	
		
	}

}
