
public class Ornek6 {

	public static void main(String[] args) {

		String site = "www.laserif.com";
		if(site.startsWith("www.")) {
			System.out.println("www. ile ba�lamaktad�r");
		}else {
			System.out.println("www. ile ba�lamamaktad�r");
		}
		
		if(site.endsWith(".com")) {
			System.out.println();
	
		}

	}

}
