
public class Ornek4 {

	public static void main(String[] args) {
		
		String yazi = "NE MUTLU T�RK'�M D�YENE";
		if(yazi.contains("t�rk")) {
			System.out.println("Metinde T�rk Kelimesi ge�mektedir.");	
			
		}else {
			System.out.println("Mwetinde T�RK kelimesi ge�memektri");
		}
		

	}

}
