
public class Ornek6 {

	public static void main(String[] args) {
		int[] sayilar = new int[5];
		
		try {
			System.out.println(sayilar[6]);
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("dizinin olmayan indisine eri�meye �al��t��nz");
			
			
		}

	}

}
