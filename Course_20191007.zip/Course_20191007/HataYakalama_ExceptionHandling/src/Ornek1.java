import java.util.Scanner;

public class Ornek1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("L�tfen Say� Griniz");
		
		try {
		int sayi = sc.nextInt();
		}catch (InputMisMatchException e) {
			System.out.println("int haricinde farkl� bir t�rde veri girdiniz.");
		}catch (Exception e) {
			
			
			// try hata olu�abilme ihtimali olan kodlar�n eklendi�i kod blo�udur.
			//catch, belirli hata t�r�ne g�re, ilgili hatan�n al�nmas� durumunda �al��acak kod blo�udur.
			//catcj bloklar� birden fazla �retilebilir. Tek �art her catch blo�undaki hata s�n�f�n�n ismi farkl� olmak zorunda�r.
			
			
		}
	}

}
