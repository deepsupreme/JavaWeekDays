
public class Ornek2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String isim = "ismek";
		
		
		try {
		System.out.println(isim.charAt(5));
		
		
		}catch(StringIndexOutOfBoundsException e) {
		System.out.println("String'in karakter uzunlu�u d��ar�s�na ��kt�n�z");	
		
		}
		

	}

}
