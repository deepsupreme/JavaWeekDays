
public class Ornek3 {

	public static void main(String[] args) {


		 		int sayi1 = 22;
				int sayi2 = 0;
				
				try {
				
				int sonuc = sayi1/sayi2;
				}catch (ArithmeticException e) {
		
				System.out.println("hata");
		 	
				
				}			

	}

}
