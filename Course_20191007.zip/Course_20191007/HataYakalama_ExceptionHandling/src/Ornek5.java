
public class Ornek5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String yazi =null;
			
				try {
					
					
			yazi.charAt(0);
			
				}catch (NullPointerException e) {
					System.out.println("string de�er atams� yap�lmadan metoduna eri�ilemez");
		
				
				}

	}

}
