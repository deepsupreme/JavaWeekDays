import java.util.Random;

public class Ornek2_Random {
	
	public static int sayiUret(int maxInt) {
		Random rnd = new Random();
		return rnd.nextInt(maxInt);
		
	}

	public static void main(String[] args) {
		int sayi1 = sayiUret(20); // 0-20 aras� say� �retir.
		int sayi2= sayiUret(10);// 0-20 aras�nda say� �retir
		
		
		
	}

}
