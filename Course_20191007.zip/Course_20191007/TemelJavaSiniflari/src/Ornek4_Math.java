
public class Ornek4_Math {

	public static void main(String[] args) {
		// Math s�n�f� metodlar�
		
		double pi= Math.PI;
		System.out.println("PI say�s�:"+pi);
		
		double e = Math.E;
		System.out.println("Euler Say�s�:"+e);
		
		double min = Math.min(90, 75);
		System.out.println("en k���k say�:"+min);
		
		double floor = Math.floor(150.70);
		System.out.println(floor);
		
		//k�s�rattan sonras�n� 0'a indirir
		
		double mutlakDeger = Math.abs(50.7);
		System.out.println("Mutlak de�er:"+mutlakDeger);
		
		double kareKok = Math.sqrt(10.8);
		System.out.println(kareKok);
		
		

	}

}
