import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.chrono.Chronology;

public class Ornek5_TarihIslemleri {

	public static void main(String[] args) {
		// Date, Calender, SimpleDateFormat
		//https://www.w3schools.com/java/java_date.asp
		//javapoint.com ve tutorialspoint.com
		
		LocalDate tarih = LocalDate.now();
		System.out.println("Tarih:"+tarih);
		
		int yil = tarih.getYear();
		System.out.println("Y�l:"+yil);
		
		int ay = tarih.getMonthValue();
		System.out.println("Ay:"+ay);
		
		int gun = tarih.getDayOfMonth();
		System.out.println("G�n:"+gun);
		
		DayOfWeek hafta_gun = tarih.getDayOfWeek();
		System.out.println("Haftan�n ka��nc� g�n�:"+hafta_gun.getValue());
		
		System.out.println("--------------------");
		
		LocalDateTime dateTime = LocalDateTime.now();
		System.out.println(dateTime.toString());
		
		int dt_yil = dateTime.getYear();
		System.out.println("Y�l:"+dt_yil);
		
		int dt_ay = dateTime.getMonthValue();
		System.out.println("Ay:"+dt_ay);
		
		int dt_gun = dateTime.getDayOfMonth();
		System.out.println("G�n:"+dt_gun);
		
		int dt_saat = dateTime.getHour();
		System.out.println("Saat:"+dt_saat);
		
		Chronology kronoloji = dateTime.getChronology();
		System.out.println("Kronolojik Takvim t�r�:"+kronoloji.getCalendarType());
		
		System.out.println("------------");
		
		Calendar takvim = new GregorianCalendar();
		System.out.println("Takvim t�r�:"+takvim.getCalenderType());
		System.out.println(takvim.getTime());
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.YYYY HH:mm");
		System.out.println("Tarih: "+sdf.format(takvim.getTime()));
		System.out.println("Tarih: "+takvim.gettime());
		
		
		
		
		
		
		
		
		
		
		

	}

}
