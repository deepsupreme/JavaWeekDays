//Say� tahmin oyunu

import java.util.Random;
import java.util.Scanner;

	public class Ornek4_Random {

	
	public static void main(String[] args) {
		
		Random rastgele = new Random();
		int gecici = rastgele.nextInt(5);
		
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("L�tfen 0 ile 5 aras�nda bir say� giriniz");
		int sayi = sc.nextInt();
		
		if(sayi==gecici) {
			System.out.println("Tebrikler say�y� buldunuz");
		}else if(sayi>gecici) {
			System.out.println("Tahmin etti�iniz say� b�y�kt�r.");
		}else if(gecici>sayi) {
			System.out.println("Tahimin etti�iniz say� k���kt�r");
			
	
		}
		

	}

}
