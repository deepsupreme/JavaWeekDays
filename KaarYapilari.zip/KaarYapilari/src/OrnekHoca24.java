
public class OrnekHoca24 {

	public static void main(String[] args) {
		String ad = "�ER�F";
		String soyad = "G�NG�R";
		
		if("�erif".equals(ad) && "g�ng�r".equals(soyad))
			System.out.println("Merhaba");
		else
			System.out.println("sizi tan�m�yorum");
		
		/*if statement, s�sl� prentez olmadan da kullan�labilir.
		 if, else if yada else at�r�ndan sonra bir girinti (tab tu�u)
		 olu�turup sade bir sat�r olarak kod yaz�labilir.
		 
		 e�er if yap�s�nda s�sl� pararntez varsa istedi�iniz kadar sat�r olu�turup kodlar� yazabiliriz.
		 */

	}

}
