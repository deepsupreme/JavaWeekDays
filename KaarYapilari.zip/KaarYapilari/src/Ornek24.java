import java.util.Scanner;
public class Ornek24 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		int kenar1,kenar2,sonuc1,sonuc2,sonuc3,sonuc4;
		
		System.out.println("Kare ise bir kenar giriniz");
		kenar1 = sc.nextInt();
		
		sonuc1 = kenar1*kenar1;
		System.out.println("Karenin alan�:"+sonuc1);
		sonuc2 = kenar1*4;
		System.out.println("Karenin �evresi:"+sonuc2);

		
		System.out.println("dikd�rgen ise ikinci kenar� giriniz");
		kenar2 = sc.nextInt();
		
		sonuc3 = kenar1*kenar2;
		System.out.println("Dikd�rtgenin alan�:"+sonuc1);
		sonuc4 = (kenar1+kenar2)*2;
		System.out.println("Dikd�rtgenin �evresi:"+sonuc2);
		
		

	}

}
