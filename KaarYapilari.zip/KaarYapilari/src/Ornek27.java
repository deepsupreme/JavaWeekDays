import java.util.Scanner;
public class Ornek26 {

	static Scanner sc;
	public static void main(String[] args) {
		
		System.out.println("mevsim se�iniz: sonbahar k�� ilkbahar yaz gibi");
		Scanner sc = new Scanner(System.in);
		
		String mevsim = sc.next();
		
		if("sonbahar".equals(mevsim))
			System.out.println("eyl�l,ekim kas�m");
		else if("k��".equals(mevsim)
			System.out.println("aral�k,ocak,�ubat");
				
		
	}

}
