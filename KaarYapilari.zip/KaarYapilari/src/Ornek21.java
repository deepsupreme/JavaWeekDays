import java.util.Scanner;
public class Ornek21 {
	
	/*KO�ULLU ��LEMLER (KARAR YAPILARI)
	 * if
	 * if-else
	 * switch-case
	 */

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		//String ad = "�erif";
		//String soyad = "g�ng�r";
		System.out.println("L�tfen ad�n�z� giriniz: ");
		String ad = sc.next();
		System.out.println("L�tfen soyad�n�z� giriniz: ");
		String soyad = sc.next();
		System.out.println("L�tfen ya��n�z� giriniz: ");
		int sene = sc.nextInt();
		int yas = 1;
		
		if(sene>=20) {
			System.out.println("DEFOL");
			
		}
		
		else if("�erif".contentEquals(ad)&& "g�ng�r".contentEquals(soyad)) {
			System.out.println("MERHABA �ER�F");
		}

	}

}
