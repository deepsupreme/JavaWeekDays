import java.util.Scanner;

public class Ornek23 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int sayi1,sayi2,sonuc;
		System.out.println("Birinci say�y� giriniz");
		sayi1 = sc.nextInt();
		System.out.println("�kinci say�y� giriniz");
		sayi2 = sc.nextInt();
		System.out.println("��lem se�iniz topla ��kar b�l �arp");
		
		String islem = sc.next();
		if("Topla".equals(islem)) 
		{
			sonuc = sayi1+sayi2;
			System.out.println("Toplama sonucu:"+sonuc);
		}else if("��kar".equals(islem)) 
		{
			sonuc = sayi1-sayi2;
			System.out.println("��karma sonucu:"+sonuc);
		}else if("�arp".equals(islem)) 
		{
			sonuc = sayi1*sayi2;
			System.out.println("�arpma sonucu:"+sonuc);	
			
		}else if ("B�l".equals(islem)) 
		{
			sonuc = sayi1-sayi2;
			System.out.println("B�lme sonucu:"+sonuc);	
		
		}

	}

}
