import java.util.Scanner;
public class Ornek26 {

	static Scanner sc;
	public static void main(String[] args) {
		
		System.out.println("i�lem se�iniz: kare daire gibi");
		Scanner sc = new Scanner(System.in);
		
		String islem = sc.next();
		
		if("kare".equals(islem)) {
			System.out.println("bir kenar uzunlu�u giriniz");
			int kenar1 = sc.nextInt();
			int alan = kenar1*kenar1;
			int cevre = kenar1*4;
			
			System.out.println("karenin alan�: "+alan);
			System.out.println("karenin �evresi:"+cevre );
			
		}else if("daire".equals(islem)) {
			System.out.println("dairenin yar��ap�n� giriniz");
			double r =sc.nextDouble();
			double PI=3.14;
					
			double alan = PI*r*r;
			double cevre = 2*PI*r;
			System.out.println("dairenin alan�: "+alan);
			System.out.println("dairenin �evresi:"+cevre);
			
		}else if("dikd�rtgen".equals(islem)) {
			
			System.out.println("dikd�rtgenin k�sa kenar�n� giriniz");
			int kisakenar = sc.nextInt();
			System.out.println("dikd�rtgenin uzun kenar�n� giriniz");
			int uzunkenar = sc.nextInt();
			
			int alan = kisakenar*uzunkenar;
			int cevre = 2*(kisakenar+uzunkenar);
			System.out.println("dikd�rtgenin alan�:"+alan);
			System.out.println("dikd�rtgenin �evresi:"+cevre);
			
		}else {
			System.out.println("yanl�� i�lem girdiniz");
			
			
		}

	}

}
