
public class Ornek22 {

	public static void main(String[] args) {
		
		String ad = "�ER�F";
		String soyad = "G�NG�R";
		String adSoyad = ad+" "+soyad;
		int yas = 20;
				
				if(yas>=21) {
					System.out.println(
							"Merhaba "+adSoyad+" ya��n�z 20'ye e�it veya b�y�kt�r..");
				}else if(yas>=15 && yas<=19) {
					System.out.println("15-20 ya� aral���ndas�n�z");
					
				}else if(yas==20) {
					System.out.println("ya��n�z 20dir");
				
				}else { System.out.println("ya��n�z 20den k��ktr");
					
				}

	}

}
